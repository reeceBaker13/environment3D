public class Main {
    public static void main(String[] args) {
        Environment environment = new Environment();
        environment.start();
    }
}